
#Program to Check if a Number is Odd or Even

num = int(input("Enter a number: "))
i = 1
while i <= 100:
         if (i % 2) == 0:  
            print("Even number",i)  
         else:  
            print("Odd number",i)
         i=i+1
