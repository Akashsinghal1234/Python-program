#wap to get minutes from user
#and print hour and left minutes

#division
#floor division

'''
n1 =10

n2 = 3

div = n1//n2

print(div)
'''
