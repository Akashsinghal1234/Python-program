
n1=90;
n2=20;
sum=n1+n2;
print(sum);

n1=90;
n2=20;
sum=n1+n2;
print(sum);
n1=90;
n2=20;
sum=n1+n2;
print(sum);
n1=90;
n2=20;
sum=n1+n2;
print(sum);
n1=90;
n2=20;
sum=n1+n2;
print(sum);
n1=90;
n2=20;
sum=n1+n2;
print(sum);


#this is called
def work():
    "this is work fuction which is doing addition task"
    n1=90;
    n2=20;
    sum=n1+n2;
    print(sum);

work()
work()
work()

def alert(s1):
    print(s1)

x=input("enter the alter statament");
alert(x)


def finalvalue(x1):
    print(x1+100)
    
def xsum():
    n1=90
    n2=80
    sum=n1+n2
    return sum

num=xsum()
print num;
finalvalue(num)



alert("hello")

def alert(s1):
    print(s1)
    







