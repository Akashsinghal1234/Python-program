#Python Program to swap two numbers without using third variable

'''
'''
# Python code to swap two numbers 
# without using another variable 
  
  
x = 5
y = 7
  
print ("Before swapping: ") 
print("Value of x : ", x, " and y : ", y) 
  
# code to swap 'x' and 'y' 
x, y = y, x 
  
print ("After swapping: ") 
print("Value of x : ", x, " and y : ", y) 
