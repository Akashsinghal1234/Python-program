#addition of twq numbers
N1=int(input("enter 1st number:"))
N2=int(input("enter 2nd number:"))
sum=N1+N2
print("sum"sum)


#TO FIND AREA OF RECTANGLE
N1=int(input("enter length number:"))
N2=int(input("enter breadth number:"))
sum=N1*N2
print("sum"sum)


#TO FIND SIMPLE INTREST
N1=int(input("enter principal:"))
N2=int(input("enter rate:"))
N3=int(input("enter time:"))
sum=N1*N2*N3/100
print("sum"sum)


#display value of n1,n2,n3
n=5
print(n,n*n,n*n*n)


#to convert temp. from c to f
c=float(input("enter temp. in celsius"))
f=c*9/5+32
print("converson from c to f is c,f)


#to find area of triangle
base=int(input("enter base of triangle"))
height=int(input("enter height of riangle"))
area=0.5*b*h
print("area",area of triangle)


#give output
x,y=7,2
x,y,x=x+,y+3,x+10
      print(x,y)


#wrie a programme
a=int("enter number 1"))
b=int("enter number 2")) 
c=int("enter number 3"))
print(a,b,c)

#to print area of circle with its radius
x=int(input("enter first number"))
y=int(input("enter second number"))
x,y=y,x+2
print(x,y)


#
name="akash"
age=21
print(name,"you are""now but")
print(name,"will be",age+1,"next year")


#
age=int(input("pls enter the age of person"))
if(age>=18):
    print("you are eligiblr to vote")
else:
    print("sorry you are not eligiblr")



#finding whether an extered the number is an an odd or even
num=int(input("enter the number"))
if(num%2==0):
    print(num,"is an even number")
else:
    print(num,"is an odd number")


#to find the largest number amoungest three
num1=int(input("enter the first number"))
num2=int(input("enter the second number"))
num3=int(input("enter the third number"))
max=num;
if(num2>max):
    max=num2
if(num=3>max):
    max=num3
print max


