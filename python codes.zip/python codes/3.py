#find the netprice after discount on the product price.

take product price from user
take discount rate from user

netprice = price - (price*discountrate/100)


1000
10%

netprice  1000 - 1000*10/100 = 900
