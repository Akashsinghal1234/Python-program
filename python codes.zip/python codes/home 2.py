N1=int(input("take 1st number"))
N2=int(input("take 2nd number"))
sum=N1/N2
print("sum",sum)

             
