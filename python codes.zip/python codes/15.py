#Python program to generate a random number

import random  
print(random.randint(1,3))  # randint(start,end-1) 
''

#Python program to convert Celsius to Fahrenheit

#c =(f-32)*5/9   fahrenheit to celsius
#f =(c*9/5)+32   celsius to fahrenheit


#Python program to convert Celsius to Fahrenheit

# Collect input from the user  
#celsius = float(input('Enter temperature in Celsius: '))  
  
# calculate temperature in Fahrenheit  
fahrenheit = celsius * (9/5) + 32  
print('Celsius is equal to degree Fahrenheit',celsius,fahrenheit)  

