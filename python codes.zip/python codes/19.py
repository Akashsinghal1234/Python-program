'''
*****
****
***
**
*
'''




i=5 #row
while i >=1:
         j=1 #column
         while j<=i:
                  print("*",end="")
                  j=j+1
         print()
         i=i-1
