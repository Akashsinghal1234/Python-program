'''
****
****
****
****
'''


i=1 #row
while i <=5:
         j=1 #column
         while j<=i:
                  print("*",end="")
                  j=j+1
         print()
         i=i+1



print(end="")
