#WAP to multiple three number and get the input from user

n1 = int(input("enter the first number"))
n2 = int(input("enter the second number"))
n3 = int(input("enter the thrid number"))
result = n1*n2*n3
print("result after multiple three is",result);
