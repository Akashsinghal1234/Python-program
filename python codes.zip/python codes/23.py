'''
****
-***
--**
---*
'''
space = 0
i = 4
while i>=1:
         p=1
         while p<=space:
                  print("-",end="")
                  p=p+1
         q=1
         while q<=i:
                  print("*",end="")
                  q=q+1
         print()
         i=i-1
         space = space +1
