#Q1
#find area of rectangle
x1=int(input("enter length"))
x2=int(input("enter breadth"))
sum=x1*x2
print("sum",sum)

#Q2
#find simple interest
x1=int(input("enter principal"))
x2=int(input("enter rate"))
x3=int(input("enter time"))
sum=x1*x2*x3/100
print("sum",sum)

#Q3
#average marks of five subject
x1=int(input("enter english marks"))
x2=int(input("enter maths marks"))
x3=int(input("enter ssc marks"))
x4=int(input("enter science marks"))
x5=int(input("enter hindi marks"))
sum=x1+x2+x3+x4+x5/500*1/100
print("sum",sum)

#Q5
#to change tempeature from c to f.
'''
