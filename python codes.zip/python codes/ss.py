age=int(input("enter the age "))
if 1:
    print("age is 18 and > than 18 vote");
    print("good");
else:
    print("age is 18 < than 18 not vote");
    print("flase");

print("reamining line 1");
print("reamining line 1");
print("reamining line 1");
print("reamining line 1");
