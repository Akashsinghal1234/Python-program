

n1=int(input("enter the  first number"));

n2=int(input("enter the second number"));

su=n1+n2;

print(su);


#this is called part
def msg():
    print("not working ");

#this is calling part
msg();
msg();


#this is called part
def msg(x):
    print(x);

#this is calling part
msg("not working");
msg("does not work");
