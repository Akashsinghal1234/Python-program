Python 3.7.3 (v3.7.3:ef4ec6ed12, Mar 25 2019, 21:26:53) [MSC v.1916 32 bit (Intel)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
===================== RESTART: C:/Users/HP/Desktop/ss.py =====================
enter the age 18
Traceback (most recent call last):
  File "C:/Users/HP/Desktop/ss.py", line 2, in <module>
    if age>=18:
TypeError: '>=' not supported between instances of 'str' and 'int'
>>> 
===================== RESTART: C:/Users/HP/Desktop/ss.py =====================
enter the age 18
age is 18 and > than 18 vote
good
reamining line 1
reamining line 1
reamining line 1
reamining line 1
>>> 
===================== RESTART: C:/Users/HP/Desktop/ss.py =====================
enter the age 7
age is 18 < than 18 not vote
flase
reamining line 1
reamining line 1
reamining line 1
reamining line 1
>>> 
===================== RESTART: C:/Users/HP/Desktop/ss.py =====================
enter the age 89
age is 18 < than 18 not vote
flase
reamining line 1
reamining line 1
reamining line 1
reamining line 1
>>> 
===================== RESTART: C:/Users/HP/Desktop/ss.py =====================
enter the age 78
age is 18 and > than 18 vote
good
reamining line 1
reamining line 1
reamining line 1
reamining line 1
>>> 
