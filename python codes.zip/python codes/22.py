'''
---*
--* *
-* * *
* * * *
'''


i = 1
space = 4
while i<=4:
         p=1
         while p<space:
                  print("-",end="")
                  p=p+1
         q=1
         while q<=i:
                  print("* ",end="")
                  q=q+1
         print()
         i=i+1
         space = space -1
