# program to reverse the number


    

x = 3456

lastnumber = x%10

remaingnumber = x//10
print(lastnumber)
print(remaingnumber)

